# Proyecto Cronologia
Este es un proyecto para la clase de Estructura de Computadores realizado por [delightfulagony](https://github.com/delightfulagony) y [Manuelbelgicano](https://github.com/Manuelbelgicano)
